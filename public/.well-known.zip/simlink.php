<?php


$target = '/home/vzeroeu/303pruebas/storage/app/public';
$shortcut = '../303pruebas/public/storage';


if(symlink($target, $shortcut)){
    echo "creado bien en teoria";
}
else{
    echo "algun error";
    print_r(error_get_last());
}

/*$target = '/home/vzeroeu/303pruebas/public';
$shortcut = '../303pruebas.vzero.eu';


if(symlink($target, $shortcut)){
    echo "creado bien en teoria";
}
else{
    echo "algun error";
    print_r(error_get_last());
}*/

?>